<?php
/**
 * @package     Joomla.Libraries
 * @subpackage  lib_drad
 *
 * @copyright   Copyright (C) 2015 Florian Denizot. All rights reserved.
 * @license     LTBD
 */

defined('_JEXEC') or die;

$item = $displayData['item'];
?>

<td class="center hidden-phone">
  <?php echo (int) $item->id; ?>
</td>