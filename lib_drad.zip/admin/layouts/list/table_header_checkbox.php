<?php
/**
 * @package     Joomla.Libraries
 * @subpackage  lib_drad
 *
 * @copyright   Copyright (C) 2015 Florian Denizot. All rights reserved.
 * @license     LTBD
 */

defined('_JEXEC') or die;
?>

<th width="1%" class="center">
  <?php echo JHtml::_('grid.checkall'); ?>
</th>